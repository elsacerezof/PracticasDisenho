﻿namespace DependencyInjection
{
    public class NetPacket
    {
    }
}