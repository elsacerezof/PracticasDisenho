﻿namespace DependencyInjection
{
    /// <summary>
    ///     Representa un paquete de datos a nivel de enlace.
    ///     
    ///     Se deja intencionadamente vacío ya que no es relevante para el propósito
    ///     del ejemplo.
    /// </summary>
    public class DataLinkPacket
    {
    } // class DataLinkPacket

} // namespace DependencyInjection